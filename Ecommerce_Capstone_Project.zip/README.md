
# Full Stack Web Development Capstone

Project: E-Commerce Product Catalog

Features:
- Modular frontend structure
- Client-side routing using hash routes
- Product catalog rendering
- Deployment-ready for Vercel, Netlify, Render
- Optimized static assets

Deployment:

Vercel:
1. Upload project to GitHub
2. Import repository into Vercel
3. Deploy

Netlify:
1. Drag and drop project folder
2. Publish site

Render:
1. Create Static Site
2. Connect GitHub repository
3. Deploy

Expected Outcome:
Production-ready public website.
