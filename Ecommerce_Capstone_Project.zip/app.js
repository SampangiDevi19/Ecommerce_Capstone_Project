
const products=[
{name:'Laptop',price:65000},
{name:'Phone',price:25000},
{name:'Headphones',price:3000},
{name:'Smart Watch',price:5000}
];

const container=document.getElementById('product-list');

products.forEach(p=>{
 const card=document.createElement('div');
 card.className='card';
 card.innerHTML=`<h3>${p.name}</h3><p>₹${p.price}</p>`;
 container.appendChild(card);
});

window.addEventListener('hashchange',()=>{
 console.log('Route:',location.hash);
});
